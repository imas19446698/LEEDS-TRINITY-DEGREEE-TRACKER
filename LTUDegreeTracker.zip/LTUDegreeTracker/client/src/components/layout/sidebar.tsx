import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import {
  Calculator,
  Calendar,
  Home,
  Settings,
  BookOpen,
  User,
  LogOut,
  Menu,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

const navigationItems = [
  { href: "/", icon: Home, label: "Dashboard" },
  { href: "/grades", icon: Calculator, label: "Grade Calculator" },
  { href: "/calendar", icon: Calendar, label: "Academic Calendar" },
  { href: "/study-tips", icon: BookOpen, label: "Study Tips" },
  { href: "/profile", icon: User, label: "Profile" },
  { href: "/settings", icon: Settings, label: "Settings" },
];

export function Sidebar() {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const Navigation = () => (
    <>
      <nav className="flex-1 px-4">
        {navigationItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <a
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md mb-1 text-sidebar-foreground hover:bg-sidebar-accent transition-colors",
                location === item.href && "bg-sidebar-accent"
              )}
              onClick={() => setIsOpen(false)}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.label}</span>
            </a>
          </Link>
        ))}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <Button
          variant="ghost"
          onClick={() => {
            logoutMutation.mutate();
          }}
          className="flex items-center gap-3 px-3 py-2 w-full rounded-md text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
        >
          <LogOut className="h-5 w-5" />
          <span>Logout</span>
        </Button>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile Sidebar */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild className="md:hidden">
          <Button variant="ghost" size="icon" className="absolute top-4 left-4">
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <div className="flex flex-col h-full bg-sidebar">
            <div className="p-6">
              <h1 className="text-2xl font-semibold text-sidebar-foreground">
                LTU Degree Tracker
              </h1>
            </div>
            <Navigation />
          </div>
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex flex-col w-64 bg-sidebar border-r border-sidebar-border h-screen">
        <div className="p-6">
          <h1 className="text-2xl font-semibold text-sidebar-foreground">
            LTU Degree Tracker
          </h1>
        </div>
        <Navigation />
      </div>
    </>
  );
}