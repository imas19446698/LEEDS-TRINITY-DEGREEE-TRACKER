import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { StudyTip } from "@shared/schema";
import { Lightbulb, Search } from "lucide-react";

export default function StudyTips() {
  const { user } = useAuth();
  const [selectedDegree, setSelectedDegree] = useState(user?.degreeType || "UG");
  const [searchSubject, setSearchSubject] = useState("");

  const { data: tips } = useQuery<StudyTip[]>({
    queryKey: ["/api/study-tips", selectedDegree, searchSubject],
  });

  const filteredTips = tips?.filter((tip) =>
    tip.subject.toLowerCase().includes(searchSubject.toLowerCase())
  );

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold mb-8 font-montserrat">Study Tips</h1>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Filter Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Select
                  value={selectedDegree}
                  onValueChange={setSelectedDegree}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select degree type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="FY">First Year</SelectItem>
                    <SelectItem value="UG">Undergraduate</SelectItem>
                    <SelectItem value="PG">Postgraduate</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by subject..."
                    value={searchSubject}
                    onChange={(e) => setSearchSubject(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredTips?.map((tip) => (
              <Card key={tip.id}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                    {tip.subject}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{tip.tip}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredTips?.length === 0 && (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No study tips found for the selected filters
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
