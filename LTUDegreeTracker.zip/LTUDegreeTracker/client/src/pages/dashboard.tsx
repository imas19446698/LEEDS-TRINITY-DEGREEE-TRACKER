import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { Subject } from "@shared/schema";
import { Loader2, BookOpen, GraduationCap, CalendarDays } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: subjects, isLoading: isLoadingSubjects } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  if (!user) return null;

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold mb-8 font-montserrat">Welcome back, {user.name}!</h1>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5" />
                Academic Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Current CGPA</span>
                    <span className="font-semibold">{user.cgpa}</span>
                  </div>
                  <Progress value={parseFloat(user.cgpa) * 25} />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Semester</span>
                    <span className="font-semibold">{user.semester}/8</span>
                  </div>
                  <Progress value={(user.semester / 8) * 100} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Latest Grades
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingSubjects ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-border" />
                </div>
              ) : (
                <div className="space-y-2">
                  {subjects?.slice(0, 3).map((subject) => (
                    <div key={subject.id} className="flex justify-between items-center">
                      <span>{subject.name}</span>
                      <span className="font-semibold">
                        {((subject.obtainedMarks / subject.totalMarks) * 100).toFixed(1)}%
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                Program Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Department</span>
                  <span className="font-semibold">{user.department}</span>
                </div>
                <div className="flex justify-between">
                  <span>Degree</span>
                  <span className="font-semibold">{user.degreeName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Type</span>
                  <span className="font-semibold">{user.degreeType}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
