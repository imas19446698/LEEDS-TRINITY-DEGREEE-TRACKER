import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Subject, insertSubjectSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Plus, Calculator } from "lucide-react";
import { z } from "zod";

// Define form schema that accepts string inputs
const subjectFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  totalMarks: z.string(),
  obtainedMarks: z.string(),
});

type SubjectForm = z.infer<typeof subjectFormSchema>;

export default function GradeCalculator() {
  const { toast } = useToast();
  const [newSubject, setNewSubject] = useState<SubjectForm>({
    name: "",
    totalMarks: "100",
    obtainedMarks: "0",
  });

  const { data: subjects, isLoading } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const addSubjectMutation = useMutation({
    mutationFn: async (data: SubjectForm) => {
      // Convert string values to numbers before sending to API
      const payload = {
        name: data.name,
        totalMarks: parseInt(data.totalMarks),
        obtainedMarks: parseInt(data.obtainedMarks),
      };
      const res = await apiRequest("POST", "/api/subjects", payload);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subjects"] });
      setNewSubject({ name: "", totalMarks: "100", obtainedMarks: "0" });
      toast({
        title: "Subject added successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add subject",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function calculateGrade(obtained: number, total: number) {
    const percentage = (obtained / total) * 100;
    if (percentage >= 90) return "A+";
    if (percentage >= 80) return "A";
    if (percentage >= 70) return "B";
    if (percentage >= 60) return "C";
    if (percentage >= 50) return "D";
    return "F";
  }

  function calculateCGPA(subjects: Subject[]) {
    if (!subjects?.length) return 0;
    const totalPoints = subjects.reduce((acc, subject) => {
      const percentage = (subject.obtainedMarks / subject.totalMarks) * 100;
      let points = 0;
      if (percentage >= 90) points = 4.0;
      else if (percentage >= 80) points = 3.5;
      else if (percentage >= 70) points = 3.0;
      else if (percentage >= 60) points = 2.5;
      else if (percentage >= 50) points = 2.0;
      return acc + points;
    }, 0);
    return (totalPoints / subjects.length).toFixed(2);
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold mb-8 font-montserrat">Grade Calculator</h1>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Add New Subject</CardTitle>
            </CardHeader>
            <CardContent>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  // Form validation
                  if (!newSubject.name) {
                    toast({
                      title: "Subject name is required",
                      variant: "destructive",
                    });
                    return;
                  }
                  const totalMarks = parseInt(newSubject.totalMarks);
                  const obtainedMarks = parseInt(newSubject.obtainedMarks);
                  if (isNaN(totalMarks) || totalMarks <= 0) {
                    toast({
                      title: "Total marks must be a positive number",
                      variant: "destructive",
                    });
                    return;
                  }
                  if (isNaN(obtainedMarks) || obtainedMarks < 0) {
                    toast({
                      title: "Obtained marks must be a non-negative number",
                      variant: "destructive",
                    });
                    return;
                  }
                  if (obtainedMarks > totalMarks) {
                    toast({
                      title: "Obtained marks cannot exceed total marks",
                      variant: "destructive",
                    });
                    return;
                  }
                  addSubjectMutation.mutate(newSubject);
                }}
                className="flex gap-4"
              >
                <Input
                  placeholder="Subject Name"
                  value={newSubject.name}
                  onChange={(e) =>
                    setNewSubject({ ...newSubject, name: e.target.value })
                  }
                  required
                />
                <Input
                  type="number"
                  placeholder="Total Marks"
                  value={newSubject.totalMarks}
                  onChange={(e) =>
                    setNewSubject({ ...newSubject, totalMarks: e.target.value })
                  }
                  required
                  min="1"
                />
                <Input
                  type="number"
                  placeholder="Obtained Marks"
                  value={newSubject.obtainedMarks}
                  onChange={(e) =>
                    setNewSubject({ ...newSubject, obtainedMarks: e.target.value })
                  }
                  required
                  min="0"
                />
                <Button type="submit" disabled={addSubjectMutation.isPending}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Subject
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Grades Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-border" />
                </div>
              ) : (
                <>
                  <div className="space-y-4">
                    {subjects?.map((subject) => (
                      <div
                        key={subject.id}
                        className="flex justify-between items-center"
                      >
                        <span>{subject.name}</span>
                        <div className="space-x-4">
                          <span>
                            {subject.obtainedMarks}/{subject.totalMarks}
                          </span>
                          <span className="font-semibold">
                            {calculateGrade(
                              subject.obtainedMarks,
                              subject.totalMarks
                            )}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-semibold">CGPA</span>
                      <span className="text-lg font-bold">
                        {calculateCGPA(subjects || [])}
                      </span>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}