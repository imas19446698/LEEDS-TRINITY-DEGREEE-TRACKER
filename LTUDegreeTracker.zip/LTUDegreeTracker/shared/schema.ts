import { pgTable, text, serial, integer, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  fatherName: text("father_name").notNull(),
  department: text("department").notNull(),
  degreeName: text("degree_name").notNull(),
  degreeType: text("degree_type").notNull(),
  semester: integer("semester").notNull(),
  cgpa: text("cgpa").notNull(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  totalMarks: integer("total_marks").notNull(),
  obtainedMarks: integer("obtained_marks").notNull(),
});

export const calendarEvents = pgTable("calendar_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  date: text("date").notNull(),
  description: text("description"),
});

export const studyTips = pgTable("study_tips", {
  id: serial("id").primaryKey(),
  degreeType: text("degree_type").notNull(),
  subject: text("subject").notNull(),
  tip: text("tip").notNull(),
});

export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  theme: text("theme").notNull().default("light"),
  language: text("language").notNull().default("en"),
  notifications: boolean("notifications").notNull().default(true),
});

export const insertUserSchema = createInsertSchema(users)
  .extend({
    password: z.string().min(6, "Password must be at least 6 characters"),
    degreeType: z.enum(["FY", "UG", "PG"]),
    semester: z.number().min(1).max(8),
  });

export const insertSubjectSchema = createInsertSchema(subjects);
export const insertCalendarEventSchema = createInsertSchema(calendarEvents);
export const insertStudyTipSchema = createInsertSchema(studyTips);
export const insertUserSettingsSchema = createInsertSchema(userSettings).extend({
  theme: z.enum(["light", "dark"]),
  language: z.enum(["en", "hi", "te"]),
  notifications: z.boolean(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type CalendarEvent = typeof calendarEvents.$inferSelect;
export type StudyTip = typeof studyTips.$inferSelect;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;