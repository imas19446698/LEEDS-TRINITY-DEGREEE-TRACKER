import { 
  users, type User, type InsertUser,
  subjects, type Subject,
  calendarEvents, type CalendarEvent,
  studyTips, type StudyTip,
  userSettings, type UserSettings, type InsertUserSettings,
  insertSubjectSchema, insertCalendarEventSchema, insertStudyTipSchema, insertUserSettingsSchema
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;

  // Subject methods
  createSubject(subject: typeof insertSubjectSchema._type): Promise<Subject>;
  getSubjectsByUserId(userId: number): Promise<Subject[]>;

  // Calendar event methods
  createCalendarEvent(event: typeof insertCalendarEventSchema._type): Promise<CalendarEvent>;
  getCalendarEventsByUserId(userId: number): Promise<CalendarEvent[]>;

  // Study tips methods
  getStudyTips(degreeType?: string, subject?: string): Promise<StudyTip[]>;

  // User settings methods
  updateUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  getUserSettings(userId: number): Promise<UserSettings | undefined>;

  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private subjects: Map<number, Subject>;
  private calendarEvents: Map<number, CalendarEvent>;
  private studyTips: Map<number, StudyTip>;
  private userSettings: Map<number, UserSettings>;
  private currentId: { [key: string]: number };
  public sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.subjects = new Map();
    this.calendarEvents = new Map();
    this.studyTips = new Map();
    this.userSettings = new Map();
    this.currentId = {
      users: 1,
      subjects: 1,
      calendarEvents: 1,
      studyTips: 1,
      userSettings: 1
    };

    // Initialize session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Clear expired entries every 24h
    });

    // Add some default study tips
    this.addDefaultStudyTips();
  }

  private addDefaultStudyTips() {
    const defaultTips: typeof insertStudyTipSchema._type[] = [
      // Planning Tips
      { degreeType: "UG", subject: "Planning", tip: "Create a semester study schedule with dedicated time slots for each subject" },
      { degreeType: "UG", subject: "Planning", tip: "Use a digital calendar to track assignment deadlines and exam dates" },
      { degreeType: "UG", subject: "Planning", tip: "Break large projects into smaller, manageable tasks with deadlines" },

      // Time Management
      { degreeType: "UG", subject: "Time Management", tip: "Use the Pomodoro Technique: 25 minutes of focused study followed by 5-minute breaks" },
      { degreeType: "UG", subject: "Time Management", tip: "Identify and eliminate time-wasting activities during study sessions" },
      { degreeType: "UG", subject: "Time Management", tip: "Set specific goals for each study session to maintain focus" },

      // Subject-Specific Tips
      { degreeType: "UG", subject: "Mathematics", tip: "Practice solving problems regularly without looking at solutions" },
      { degreeType: "UG", subject: "Mathematics", tip: "Create summary sheets of formulas and their applications" },
      { degreeType: "UG", subject: "Mathematics", tip: "Teach concepts to others to reinforce understanding" },

      { degreeType: "UG", subject: "Physics", tip: "Focus on understanding concepts rather than memorizing formulas" },
      { degreeType: "UG", subject: "Physics", tip: "Draw diagrams to visualize problems and solutions" },
      { degreeType: "UG", subject: "Physics", tip: "Connect theoretical concepts to real-world applications" },

      // Postgraduate Tips
      { degreeType: "PG", subject: "Research", tip: "Maintain a detailed research journal to track progress and ideas" },
      { degreeType: "PG", subject: "Research", tip: "Set up regular meetings with your advisor to discuss progress" },
      { degreeType: "PG", subject: "Research", tip: "Join or create study groups with fellow researchers" },

      { degreeType: "PG", subject: "Writing", tip: "Write daily, even if just for 30 minutes" },
      { degreeType: "PG", subject: "Writing", tip: "Use reference management software to organize citations" },
      { degreeType: "PG", subject: "Writing", tip: "Create detailed outlines before starting major writing projects" },

      // First Year Tips
      { degreeType: "FY", subject: "Adaptation", tip: "Attend all orientation sessions and campus tours" },
      { degreeType: "FY", subject: "Adaptation", tip: "Join study groups to meet classmates and share knowledge" },
      { degreeType: "FY", subject: "Adaptation", tip: "Visit professors during office hours to build relationships" },

      { degreeType: "FY", subject: "Organization", tip: "Create a digital folder system for each course" },
      { degreeType: "FY", subject: "Organization", tip: "Review and organize notes within 24 hours of each class" },
      { degreeType: "FY", subject: "Organization", tip: "Keep a backup of all important documents and assignments" }
    ];

    defaultTips.forEach(tip => {
      const id = this.currentId.studyTips++;
      this.studyTips.set(id, { ...tip, id });
    });
  }

  // Other methods remain unchanged
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error(`User with id ${id} not found`);

    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createSubject(subject: typeof insertSubjectSchema._type): Promise<Subject> {
    const id = this.currentId.subjects++;
    const newSubject: Subject = { ...subject, id };
    this.subjects.set(id, newSubject);
    return newSubject;
  }

  async getSubjectsByUserId(userId: number): Promise<Subject[]> {
    return Array.from(this.subjects.values()).filter(
      subject => subject.userId === userId
    );
  }

  async createCalendarEvent(event: typeof insertCalendarEventSchema._type): Promise<CalendarEvent> {
    const id = this.currentId.calendarEvents++;
    const newEvent: CalendarEvent = { ...event, id };
    this.calendarEvents.set(id, newEvent);
    return newEvent;
  }

  async getCalendarEventsByUserId(userId: number): Promise<CalendarEvent[]> {
    return Array.from(this.calendarEvents.values()).filter(
      event => event.userId === userId
    );
  }

  async getStudyTips(degreeType?: string, subject?: string): Promise<StudyTip[]> {
    let tips = Array.from(this.studyTips.values());
    if (degreeType) {
      tips = tips.filter(tip => tip.degreeType === degreeType);
    }
    if (subject) {
      tips = tips.filter(tip => tip.subject.toLowerCase().includes(subject.toLowerCase()));
    }
    return tips;
  }

  async updateUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const existingSettings = await this.getUserSettings(settings.userId);
    const id = existingSettings?.id ?? this.currentId.userSettings++;
    const updatedSettings: UserSettings = { ...settings, id };
    this.userSettings.set(id, updatedSettings);
    return updatedSettings;
  }

  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    return Array.from(this.userSettings.values()).find(
      settings => settings.userId === userId
    );
  }
}

export const storage = new MemStorage();