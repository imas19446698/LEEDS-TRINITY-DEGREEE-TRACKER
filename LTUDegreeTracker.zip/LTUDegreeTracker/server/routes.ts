import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";
import { insertSubjectSchema, insertCalendarEventSchema, insertStudyTipSchema, insertUserSettingsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Subject routes
  app.post("/api/subjects", async (req, res) => {
    const data = insertSubjectSchema.parse({ ...req.body, userId: req.user!.id });
    const subject = await storage.createSubject(data);
    res.json(subject);
  });

  app.get("/api/subjects", async (req, res) => {
    const subjects = await storage.getSubjectsByUserId(req.user!.id);
    res.json(subjects);
  });

  // Calendar events routes
  app.post("/api/events", async (req, res) => {
    const data = insertCalendarEventSchema.parse({ ...req.body, userId: req.user!.id });
    const event = await storage.createCalendarEvent(data);
    res.json(event);
  });

  app.get("/api/events", async (req, res) => {
    const events = await storage.getCalendarEventsByUserId(req.user!.id);
    res.json(events);
  });

  // Study tips routes
  app.get("/api/study-tips", async (req, res) => {
    const { degreeType, subject } = req.query;
    const tips = await storage.getStudyTips(degreeType as string, subject as string);
    res.json(tips);
  });

  // User settings routes
  app.post("/api/settings", async (req, res) => {
    const data = insertUserSettingsSchema.parse({ ...req.body, userId: req.user!.id });
    const settings = await storage.updateUserSettings(data);
    res.json(settings);
  });

  app.get("/api/settings", async (req, res) => {
    const settings = await storage.getUserSettings(req.user!.id);
    res.json(settings);
  });

  // Profile update route
  app.patch("/api/profile", async (req, res) => {
    const data = z.object({
      name: z.string().optional(),
      fatherName: z.string().optional(),
      department: z.string().optional(),
      degreeName: z.string().optional(),
      degreeType: z.enum(["FY", "UG", "PG"]).optional(),
      semester: z.number().min(1).max(8).optional(),
    }).parse(req.body);

    const updatedUser = await storage.updateUser(req.user!.id, data);
    res.json(updatedUser);
  });

  const httpServer = createServer(app);
  return httpServer;
}
