# LTUDegreeTracker  

## GitHub Repository
[Click here to view the repository](https://github.com/your-username/LTUDegreeTracker)  

## App Design and Implementation Plan 
LTUDegreeTracker is a mobile and web application designed to help students track their academic progress efficiently. The app provides features such as:  
- Course tracking and grade calculation  
- Study tips and personalized recommendations  
- Profile management and progress visualization  

Implementation Approach: 
1. Front-End: Built using TypeScript, Tailwind CSS, and React/Vite.  
2. Back-End:Node.js and Firebase for authentication and data storage.  
3. Database:SQLite for offline data persistence.  
4. Deployment: Hosted on Vercel (for web) and packaged as an APK for Android.  

## Monetisation Plan 
The monetization strategy for LTUDegreeTracker includes:  
- Freemium Model: The core features are free, but advanced analytics and study tips require a subscription.  
- Advertisements: Integrating non-intrusive ads within the app.  
- Partnerships: Collaborating with educational platforms for sponsored content.  
- In-App Purchases: Offering premium templates and personalized study plans.  

## App Demonstration
A video demonstration of the app's key features can be found here:  
[Click to watch the demo](https://your-video-link.com)  

## Lab Task Evidence 
The repository includes proof of lab task completion, organized into clearly labeled folders:  
- `Assignment_1/`  
- `Assignment_2/`  
- `Session_1/`  
- `Session_2/`  

Each folder contains relevant code files, screenshots, and documentation for lab work.  

---

This README now reflects LTUDegreeTracker instead of DegreePathFinder. Let me know if you need any further changes! 🚀
