
# DegreeCalcApp

## Overview

DegreeCalcApp is an Android application designed to help students calculate their university degree classifications based on their module performance across Level 5 and Level 6. The app incorporates Firebase for user authentication and data storage, supports dark mode, provides multiple degree classification calculation methods, and includes validation and testing features to meet advanced academic requirements.

---

## Features

- User Authentication (Firebase)
- Degree classification calculation based on 4 weighting methods
- Input validation for module codes and credit values
- Layout validation for multiple screen sizes
- Theme toggle between light and dark modes
- Data persistence using Firebase Firestore
- Testing using JUnit for classification logic and input validation

---

## GitHub Repository

[GitHub Repository] https://github.com/imas19446698/LEEDS-TRINITY-DEGREEE-TRACKER

---

## App Design & Implementation Plan

The app follows a modular design with activities representing core functionalities:
- `MainActivity` for navigation
- `LoginActivity` for user authentication
- `DegreeCalculatorActivity` for entering module data
- `ResultActivity` for displaying classification
- `CalendarActivity`, `GradeTrackerActivity`, and `ProfileActivity` for extended features

We used a component-based XML layout structure with appropriate constraints and validation tools in Android Studio to ensure UI consistency.

---

## Monetisation Plan

- **Freemium Model**: Basic classification features free, advanced analytics and tips behind a small paywall.
- **Ad Integration**: Non-intrusive ads for free users using AdMob.
- **Data Analytics**: (Optional) Anonymous usage data could provide academic insights in collaboration with institutions.

---


---

## Testing & Validation

- **JUnit Testing**: All four classification methods and input validation logic are tested with sample values.
- **Firebase Integration**: Tested saving/retrieval of classifications per user using mock data.
- **Espresso UI Testing**: (Basic setup in place)
- **Layout Validation Tool**: Used Android Studio's visual layout validation across phone, foldable, and desktop screens.

---

## Database Design

We evaluated options like Room, SQLite, and Firebase Firestore. Firestore was selected due to its:
- Real-time syncing
- Scalability
- Seamless integration with Firebase Authentication

**Entity-Relationship Overview:**
- Users → [Grades, Events, Profiles]
- Grades store Level 5/6 module scores with calculated classifications

---

## Challenges & Resolutions

| Challenge | Resolution |
|----------|------------|
| Handling complex classification logic | Broke down logic into modular methods and validated via TDD |
| Input validation for module codes | Implemented prefix checks with alert dialogs |
| Dark mode theme conflict | Separated themes into values and values-night folders with override styles |

---

## References

- Google. (n.d.). [Firebase Documentation](https://firebase.google.com/docs)
- Android Developers. (n.d.). [Material Design Guidelines](https://developer.android.com/guide/topics/ui/look-and-feel)
- Vogella. (n.d.). [JUnit Tutorial](https://www.vogella.com/tutorials/JUnit/article.html)
- Google. (n.d.). [Layout Validation](https://developer.android.com/studio/write/layout-editor)

