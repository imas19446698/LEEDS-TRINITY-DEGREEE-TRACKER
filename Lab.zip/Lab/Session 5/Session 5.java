import java.sql.*;
import java.util.Scanner;

public class BankingSystem {
    // JDBC Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/bankdb";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    private static Connection conn;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Welcome to the Banking System");

            while (true) {
                System.out.println("\nMain Menu:");
                System.out.println("1. Admin Options");
                System.out.println("2. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                if (choice == 1) {
                    adminOptions();
                } else if (choice == 2) {
                    System.out.println("Exiting...");
                    break;
                } else {
                    System.out.println("Invalid option. Try again.");
                }
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Admin options menu
    private static void adminOptions() throws SQLException {
        while (true) {
            System.out.println("\nAdmin Options:");
            System.out.println("1. Insert Account");
            System.out.println("2. Delete Account");
            System.out.println("3. Update Account Balance");
            System.out.println("4. View All Accounts");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    insertAccount();
                    break;
                case 2:
                    deleteAccount();
                    break;
                case 3:
                    updateAccount();
                    break;
                case 4:
                    viewAccounts();
                    break;
                case 5:
                    return; // Return to main menu
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    // Insert a new account
    private static void insertAccount() throws SQLException {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Account Type (Savings/Checking): ");
        String accountType = scanner.nextLine();
        System.out.print("Enter Initial Balance: ");
        double balance = scanner.nextDouble();

        String query = "INSERT INTO Accounts (user_id, account_type, balance) VALUES (?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setInt(1, userId);
        pstmt.setString(2, accountType);
        pstmt.setDouble(3, balance);

        int rows = pstmt.executeUpdate();
        if (rows > 0) {
            System.out.println("Account added successfully.");
        } else {
            System.out.println("Failed to add account.");
        }
    }

    // Delete an account
    private static void deleteAccount() throws SQLException {
        System.out.print("Enter Account ID to delete: ");
        int accountId = scanner.nextInt();

        String query = "DELETE FROM Accounts WHERE account_id = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setInt(1, accountId);

        int rows = pstmt.executeUpdate();
        if (rows > 0) {
            System.out.println("Account deleted successfully.");
        } else {
            System.out.println("Account ID not found.");
        }
    }

    // Update account balance
    private static void updateAccount() throws SQLException {
        System.out.print("Enter Account ID to update: ");
        int accountId = scanner.nextInt();
        System.out.print("Enter New Balance: ");
        double newBalance = scanner.nextDouble();

        String query = "UPDATE Accounts SET balance = ? WHERE account_id = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setDouble(1, newBalance);
        pstmt.setInt(2, accountId);

        int rows = pstmt.executeUpdate();
        if (rows > 0) {
            System.out.println("Account balance updated successfully.");
        } else {
            System.out.println("Account ID not found.");
        }
    }

    // View all accounts
    private static void viewAccounts() throws SQLException {
        String query = "SELECT * FROM Accounts";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);

        System.out.println("\nAccounts List:");
        System.out.printf("%-10s %-10s %-15s %-10s\n", "Account ID", "User ID", "Account Type", "Balance");
        while (rs.next()) {
            int accountId = rs.getInt("account_id");
            int userId = rs.getInt("user_id");
            String accountType = rs.getString("account_type");
            double balance = rs.getDouble("balance");

            System.out.printf("%-10d %-10d %-15s %-10.2f\n", accountId, userId, accountType, balance);
        }
    }
}

// Code Explanation 
// Database Connection:

// The URL, USER, and PASSWORD connect to the database using JDBC.
// Admin Options:

// A submenu where the administrator can:
// Insert a new account.
// Delete an existing account using account_id.
// Update an account's balance using account_id.
// View all accounts in the Accounts table.
// CRUD Operations:

// Each operation uses prepared statements to ensure security and avoid SQL injection.
// User Input:

// The program uses Scanner to interact with the administrator.

// Code Output Example

// Main Menu / Admin Options:
// Admin Options:
// 1. Insert Account
// 2. Delete Account
// 3. Update Account Balance
// 4. View All Accounts
// 5. Back to Main Menu
// Enter your choice: 4

// Example of your accounts

// Accounts List:
// Account ID User ID   Account Type    Balance
// 1          024       Savings         5000.00
// 2          950       Current         3000.00



