// Base class Vehicle
class Vehicle {
    // Method to display general vehicle info
    public void displayInfo() {
        System.out.println("This is a vehicle.");
    }

    // Method to demonstrate starting a vehicle
    public void startEngine() {
        System.out.println("The vehicle's engine is starting.");
    }
}

// Subclass Car inheriting from Vehicle
class Car extends Vehicle {
    // Overriding the displayInfo method
    @Override
    public void displayInfo() {
        System.out.println("This is a car. Cars are fast and comfortable.");
    }

    // Additional method specific to Car
    public void playMusic() {
        System.out.println("Car is playing music.");
    }
}

// Subclass Bike inheriting from Vehicle
class Bike extends Vehicle {
    // Overriding the startEngine method
    @Override
    public void startEngine() {
        System.out.println("The bike's engine is starting with a roar!");
    }

    // Additional method specific to Bike
    public void doWheelie() {
        System.out.println("The bike is doing a wheelie!");
    }
}

// Subclass Truck inheriting from Vehicle
class Truck extends Vehicle {
    // Overriding the displayInfo method
    @Override
    public void displayInfo() {
        System.out.println("This is a truck. Trucks are used to transport goods.");
    }

    // Additional method specific to Truck
    public void loadCargo() {
        System.out.println("The truck is loading cargo.");
    }
}

// Main class to test the inheritance
public class Main {
    public static void main(String[] args) {
        // Create an instance of Car
        Car car = new Car();
        System.out.println("=== Car Details ===");
        car.displayInfo();  // Overridden method
        car.startEngine();  // Inherited method from Vehicle
        car.playMusic();    // Car-specific method

        // Create an instance of Bike
        Bike bike = new Bike();
        System.out.println("\n=== Bike Details ===");
        bike.displayInfo();  // Inherited method from Vehicle
        bike.startEngine();  // Overridden method
        bike.doWheelie();    // Bike-specific method

        // Create an instance of Truck
        Truck truck = new Truck();
        System.out.println("\n=== Truck Details ===");
        truck.displayInfo(); // Overridden method
        truck.startEngine(); // Inherited method from Vehicle
        truck.loadCargo();   // Truck-specific method
    }
}

// Code Explenation 
// Base Class Vehicle:

// Contains two general methods: displayInfo() and startEngine().
// Subclasses (Car, Bike, Truck):

// Each subclass overrides at least one method from Vehicle.
// They also have unique methods specific to their type.
// Main Method:

// Creates objects of Car, Bike, and Truck.
// Calls both overridden and inherited methods.
// Demonstrates polymorphism as each subclass provides its own implementation of the base class method.

// Below is a example of the output when the code is ran:

// === Car Details ===
// This is a car. Cars are fast and comfortable.
// The vehicle's engine is starting.
// Car is playing music.

// === Bike Details ===
// This is a vehicle.
// The bike's engine is starting with a roar!
// The bike is doing a wheelie!

// === Truck Details ===
// This is a truck. Trucks are used to transport goods.
// The vehicle's engine is starting.
// The truck is loading cargo.
