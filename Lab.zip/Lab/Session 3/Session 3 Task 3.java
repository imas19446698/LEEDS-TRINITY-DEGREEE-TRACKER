// Base class: Animal
public class Animal {
    String name;
    int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Generic makeSound method
    public void makeSound() {
        System.out.println("Animal makes a sound.");
    }

    public void eat() {
        System.out.println(name + " is eating.");
    }

    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

// Subclass 1: Dog
class Dog extends Animal {
    public Dog(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println("Dog barks.");
    }
}

// Subclass 2: Cat
class Cat extends Animal {
    public Cat(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println("Cat meows.");
    }
}

// Subclass 3: Bird
class Bird extends Animal {
    public Bird(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println("Bird chirps.");
    }
}

// FoodItem class
class FoodItem {
    String name;
    int shelfLife; // in days

    public FoodItem(String name, int shelfLife) {
        this.name = name;
        this.shelfLife = shelfLife;
    }

    public void displayDetails() {
        System.out.println("Food Name: " + name + ", Shelf Life: " + shelfLife + " days");
    }
}

// Subclass 1: CannedFood
class CannedFood extends FoodItem {
    public CannedFood(String name, int shelfLife) {
        super(name, shelfLife);
    }

    public void storageInfo() {
        System.out.println(name + " should be stored in a cool, dry place.");
    }
}

// Subclass 2: DryFood
class DryFood extends FoodItem {
    public DryFood(String name, int shelfLife) {
        super(name, shelfLife);
    }

    public void storageInfo() {
        System.out.println(name + " should be stored in an airtight container.");
    }
}

// Main class for testing
public class Main {
    public static void main(String[] args) {
        System.out.println("Testing Animal Classes with Polymorphism:\n");

        // Array of Animal objects
        Animal[] animals = new Animal[3];
        animals[0] = new Dog("Buddy", 5);
        animals[1] = new Cat("Whiskers", 3);
        animals[2] = new Bird("Tweety", 2);

        // Iterate and call makeSound() method
        for (Animal animal : animals) {
            animal.displayInfo();
            animal.makeSound();
            System.out.println();
        }

        System.out.println("Testing FoodItem Classes:\n");

        // Testing FoodItem classes
        CannedFood cannedFood = new CannedFood("Canned Beans", 365);
        cannedFood.displayDetails();
        cannedFood.storageInfo();

        DryFood dryFood = new DryFood("Rice", 730);
        dryFood.displayDetails();
        dryFood.storageInfo();
    }
}

// Code Explanation:
// Polymorphism: The makeSound() method dynamically executes the correct implementation in the subclasses.
// Inheritance: Dog, Cat, and Bird inherit from Animal. Similarly, CannedFood and DryFood inherit from FoodItem.
// Method Overriding: Subclasses override the makeSound() method of the Animal class.
// Reusability: Common properties and methods are reused in subclasses via inheritance.

// Below is a example of the code when is ran:
// Testing Animal Classes with Polymorphism:

// Name: Buddy, Age: 5
// Dog barks.

// Name: Whiskers, Age: 3
// Cat meows.

// Name: Tweety, Age: 2
// Bird chirps.

// Testing FoodItem Classes:

// Food Name: Canned Beans, Shelf Life: 365 days
// Canned Beans should be stored in a cool, dry place.

// Food Name: Rice, Shelf Life: 730 days
// Rice should be stored in an airtight container.
