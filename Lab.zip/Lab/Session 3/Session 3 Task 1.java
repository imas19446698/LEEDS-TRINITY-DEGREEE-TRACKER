// Animal class
public class Animal {
    String name;
    int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void eat() {
        System.out.println(name + " is eating.");
    }

    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

// Subclass 1: Dog
class Dog extends Animal {
    public Dog(String name, int age) {
        super(name, age);
    }

    public void bark() {
        System.out.println(name + " is barking.");
    }
}

// Subclass 2: Cat
class Cat extends Animal {
    public Cat(String name, int age) {
        super(name, age);
    }

    public void meow() {
        System.out.println(name + " is meowing.");
    }
}

// FoodItem class
class FoodItem {
    String name;
    int shelfLife; // in days

    public FoodItem(String name, int shelfLife) {
        this.name = name;
        this.shelfLife = shelfLife;
    }

    public void displayDetails() {
        System.out.println("Food Name: " + name + ", Shelf Life: " + shelfLife + " days");
    }
}

// Subclass 1: CannedFood
class CannedFood extends FoodItem {
    public CannedFood(String name, int shelfLife) {
        super(name, shelfLife);
    }

    public void storageInfo() {
        System.out.println(name + " should be stored in a cool, dry place.");
    }
}

// Subclass 2: DryFood
class DryFood extends FoodItem {
    public DryFood(String name, int shelfLife) {
        super(name, shelfLife);
    }

    public void storageInfo() {
        System.out.println(name + " should be stored in an airtight container.");
    }
}

// Main class for testing
public class Main {
    public static void main(String[] args) {
        // Testing Animal classes
        System.out.println("Testing Animal Classes:");
        Dog dog = new Dog("Buddy", 5);
        dog.displayInfo();
        dog.eat();
        dog.bark();

        Cat cat = new Cat("Whiskers", 3);
        cat.displayInfo();
        cat.eat();
        cat.meow();

        System.out.println("\nTesting FoodItem Classes:");
        // Testing FoodItem classes
        CannedFood cannedFood = new CannedFood("Canned Beans", 365);
        cannedFood.displayDetails();
        cannedFood.storageInfo();

        DryFood dryFood = new DryFood("Rice", 730);
        dryFood.displayDetails();
        dryFood.storageInfo();
    }
}


///Code Explanation: 
/// Animal Class and Subclasses:
/// The Animal class has attributes name and age with methods eat() and displayInfo().
///Dog and Cat extend Animal, adding bark() and meow() methods, respectively.

///FoodItem Class and Subclasses:
/// FoodItem has attributes name and shelfLife with a method displayDetails().
/// CannedFood and DryFood are subclasses of FoodItem, each with a specific storageInfo() method.

///Main Class:
/// The Main class creates instances of Dog, Cat, CannedFood, and DryFood classes.
/// Methods are called to print details and demonstrate functionality.

// Below is a example of the code when is ran:
// Name: Buddy, Age: 5
// Buddy is eating.
// Buddy is barking.
// Name: Whiskers, Age: 3
// Whiskers is eating.
// Whiskers is meowing.

// Testing FoodItem Classes:
// Food Name: Canned Beans, Shelf Life: 365 days
// Canned Beans should be stored in a cool, dry place.
// Food Name: Rice, Shelf Life: 730 days
// Rice should be stored in an airtight container.
