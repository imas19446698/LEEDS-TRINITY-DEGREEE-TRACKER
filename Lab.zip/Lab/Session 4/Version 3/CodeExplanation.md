<!-- Code Explanation -->
<!-- Dynamic Storage with ArrayList:

ArrayList<BankAccount> stores account objects dynamically, removing the limitations of fixed arrays.
Encapsulation:

The BankAccount class encapsulates all account details and behavior.
Access to account properties is controlled via getters and public methods.
Improved Code Readability:

Code for creating accounts, depositing, withdrawing, and listing accounts is modular and clean.
Validation:

Prevents duplicate account numbers.
Ensures deposits and withdrawals are positive. -->

<!-- Code Output Example -->
<!-- 
=== Advanced Banking System ===
1. Create Account
2. Deposit Money
3. Withdraw Money
4. Check Balance
5. List All Accounts
6. Exit
Enter your choice: 1

Enter Account Number: 054310165
Enter Account Holder's Name: Sami Ahmad
Enter Initial Deposit Amount: 500
Account created successfully!

=== Advanced Banking System ===
1. Create Account
2. Deposit Money
3. Withdraw Money
4. Check Balance
5. List All Accounts
6. Exit
Enter your choice: 5

=== Account List ===
Account Number: 054310165
Account Holder: Sami Ahmad
Balance: 500.0
----------------------- -->


