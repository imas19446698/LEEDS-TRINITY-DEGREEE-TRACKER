@Service
public class MyService {
    public String getServiceMessage() {
        return "Service is working!";
    }
}

@RestController
public class MyController {
    private final MyService service;

    @Autowired
    public MyController(MyService service) {
        this.service = service;
    }

    @GetMapping("/message")
    public String getMessage() {
        return service.getServiceMessage();
    }
}


<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
