<!-- Code Explanation
The PasswordValidator class checks if a password meets specific criteria:

Validation Rules:

isValidLength: Ensures the password has at least 8 characters.
containsUppercase: Ensures the password contains at least one uppercase letter (A-Z).
containsLowercase: Ensures the password contains at least one lowercase letter (a-z).
containsNumber: Ensures the password contains at least one number (0-9).
containsSpecialChar: Ensures the password contains at least one special character (!@#$%^&*()).
Validation Logic:

The validate method runs all the above checks, returning true if all conditions are met.
Test Cases:

The JUnit test class (PasswordValidatorTest) contains methods that test different scenarios:
A valid password (e.g., "Strong1!").
Invalid passwords that fail one or more rules. -->


<!-- Example Output

[INFO] Running PasswordValidatorTest
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.012 s - in PasswordValidatorTest

[INFO] BUILD SUCCESS -->



<!-- Code Explanation
This Spring Boot application has:

DemoApplication:

The main entry point of the Spring Boot app.
Starts an embedded web server (like Tomcat) and hosts the application.
HelloController:

A REST controller that defines an HTTP GET endpoint (/hello).
When accessed, it returns the string "Hello, Spring Boot!". -->

<!-- Example Output 
Hello, Spring Boot!
-->


<!-- Code Explanation
This example demonstrates Dependency Injection in Spring:

MyService:

A service class marked with @Service that contains a business logic method getServiceMessage.
MyController:

A REST controller marked with @RestController.
Uses @Autowired (or constructor injection) to inject the MyService bean.
Defines a GET endpoint (/message) that calls the service and returns its message. -->

<!-- Example Output 
Service is working!
-->

<!-- Code Explanation
Adding the spring-boot-starter-actuator dependency enables monitoring endpoints. By default:

The /actuator/health endpoint provides the health status of the application. -->

<!-- Example output 
{
    "status": "UP"
}
-->