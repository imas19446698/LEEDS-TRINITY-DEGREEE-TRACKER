<dependency>
    <groupId>org.junit.jupiter</groupId>
    <artifactId>junit-jupiter</artifactId>
    <version>5.10.0</version>
    <scope>test</scope>
</dependency>


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BasicTest {
    @Test
    void sampleTest() {
        assertEquals(2, 1 + 1);
    }
}




