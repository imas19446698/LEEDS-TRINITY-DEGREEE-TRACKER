import java.util.Scanner;

public class SimpleBankingSystem {

    // Constants and variables for the banking system
    static int MAX_ACCOUNTS = 100; // Maximum number of accounts allowed
    static int accountCount = 0;   // Current number of accounts created
    static int[] accountNumbers = new int[MAX_ACCOUNTS]; // Array to store account numbers
    static String[] accountHolders = new String[MAX_ACCOUNTS]; // Array to store account holder names
    static double[] accountBalances = new double[MAX_ACCOUNTS]; // Array to store account balances

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Scanner to read user input
        int choice;

        while (true) { // Infinite loop for the main menu
            displayMenu(); // Display the menu options
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt(); // Read user choice

            // Execute actions based on the user's choice
            switch (choice) {
                case 1:
                    createAccount(scanner); // Option to create a new account
                    break;
                case 2:
                    depositMoney(scanner); // Option to deposit money into an account
                    break;
                case 3:
                    withdrawMoney(scanner); // Option to withdraw money from an account
                    break;
                case 4:
                    checkBalance(scanner); // Option to check account balance
                    break;
                case 5:
                    listAllAccounts(); // Option to display all accounts
                    break;
                case 6:
                    // Exit the program
                    System.out.println("Thank you for using the banking system. Goodbye!");
                    System.exit(0);
                default:
                    // Handle invalid choices
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    // Method to display the main menu
    public static void displayMenu() {
        System.out.println("\n========================================");
        System.out.println("          Simple Banking System         ");
        System.out.println("========================================");
        System.out.println("1. Create Account");
        System.out.println("2. Deposit Money");
        System.out.println("3. Withdraw Money");
        System.out.println("4. Check Balance");
        System.out.println("5. List All Accounts");
        System.out.println("6. Exit");
        System.out.println("========================================");
    }

    // Method to create a new account
    public static void createAccount(Scanner scanner) {
        if (accountCount >= MAX_ACCOUNTS) { // Check if the account limit is reached
            System.out.println("Cannot create more accounts. Maximum limit reached.");
            return;
        }

        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt(); // Read account number
        scanner.nextLine(); // Consume leftover newline

        System.out.print("Enter Account Holder's Name: ");
        String accHolder = scanner.nextLine(); // Read account holder's name

        System.out.print("Enter Initial Deposit Amount: ");
        double initialDeposit = scanner.nextDouble(); // Read initial deposit amount

        if (initialDeposit < 0) { // Check for negative deposit amounts
            System.out.println("Initial deposit cannot be negative.");
            return;
        }

        // Store account details in respective arrays
        accountNumbers[accountCount] = accNumber;
        accountHolders[accountCount] = accHolder;
        accountBalances[accountCount] = initialDeposit;
        accountCount++; // Increment the number of accounts
        System.out.println("Account created successfully!");
    }

    // Method to deposit money into an account
    public static void depositMoney(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt(); // Read account number
        int index = findAccountIndex(accNumber); // Find the account index using the account number

        if (index == -1) { // Check if account exists
            System.out.println("Account not found!");
            return;
        }

        System.out.print("Enter Deposit Amount: ");
        double depositAmount = scanner.nextDouble(); // Read deposit amount

        if (depositAmount <= 0) { // Validate deposit amount
            System.out.println("Deposit amount must be positive.");
            return;
        }

        accountBalances[index] += depositAmount; // Add deposit amount to account balance
        System.out.println("Money deposited successfully! New Balance: $" + String.format("%.2f", accountBalances[index]));
    }

    // Method to withdraw money from an account
    public static void withdrawMoney(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt(); // Read account number
        int index = findAccountIndex(accNumber); // Find the account index using the account number

        if (index == -1) { // Check if account exists
            System.out.println("Account not found!");
            return;
        }

        System.out.print("Enter Withdrawal Amount: ");
        double withdrawAmount = scanner.nextDouble(); // Read withdrawal amount

        if (withdrawAmount <= 0) { // Validate withdrawal amount
            System.out.println("Withdrawal amount must be positive.");
            return;
        }

        if (withdrawAmount > accountBalances[index]) { // Check if sufficient balance is available
            System.out.println("Insufficient balance!");
            return;
        }

        // Confirm withdrawal from the user
        System.out.println("You are about to withdraw $" + String.format("%.2f", withdrawAmount) + " from account: " + accountNumbers[index]);
        System.out.print("Confirm withdrawal? (yes/no): ");
        scanner.nextLine(); // Consume leftover newline
        String confirmation = scanner.nextLine();

        if (confirmation.equalsIgnoreCase("yes")) { // Process withdrawal if confirmed
            accountBalances[index] -= withdrawAmount; // Deduct withdrawal amount from account balance
            System.out.println("Money withdrawn successfully! New Balance: $" + String.format("%.2f", accountBalances[index]));
        } else { // Cancel withdrawal
            System.out.println("Withdrawal canceled.");
        }
    }

    // Method to check account balance
    public static void checkBalance(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt(); // Read account number
        int index = findAccountIndex(accNumber); // Find the account index using the account number

        if (index == -1) { // Check if account exists
            System.out.println("Account not found!");
            return;
        }

        // Display account details
        System.out.println("\nAccount Holder: " + accountHolders[index]);
        System.out.println("Account Balance: $" + String.format("%.2f", accountBalances[index]));
    }

    // Method to list all accounts
    public static void listAllAccounts() {
        if (accountCount == 0) { // Check if there are no accounts
            System.out.println("No accounts available.");
            return;
        }

        System.out.println("\n=== Account List ===");
        for (int i = 0; i < accountCount; i++) { // Loop through all accounts
            System.out.println("Account Number: " + accountNumbers[i]);
            System.out.println("Account Holder: " + accountHolders[i]);
            System.out.println("Account Balance: $" + String.format("%.2f", accountBalances[i]));
            System.out.println("-----------------------");
        }
    }

    // Utility method to find the index of an account using the account number
    public static int findAccountIndex(int accNumber) {
        for (int i = 0; i < accountCount; i++) { // Loop through accounts
            if (accountNumbers[i] == accNumber) { // Check if account number matches
                return i; // Return the index of the account
            }
        }
        return -1; // Return -1 if account is not found
    }
}



// Code Explanation
// GUI Improvements:

// Clearer menu layout with separators for better readability.
// All monetary values are formatted to two decimal places for a polished output.
// Confirmation steps for withdrawal operations.
// Withdrawal Improvements:

// A confirmation prompt before deducting the amount from the account.
// Canceled transactions leave the account balance unchanged.
// User Feedback:

// Detailed and formatted messages guide the user through the process, reducing errors and enhancing usability.



// Example Output

// ========================================
//           Simple Banking System         
// ========================================
// 1. Create Account
// 2. Deposit Money
// 3. Withdraw Money
// 4. Check Balance
// 5. List All Accounts
// 6. Exit
// ========================================
// Enter your choice: 3
// Enter Account Number: 01234
// Enter Withdrawal Amount: 300.00
// You are about to withdraw $300.00 from account: 01234
// Confirm withdrawal? (yes/no): yes
// Money withdrawn successfully! New Balance: $700.00





